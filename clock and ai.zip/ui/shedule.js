document.addEventListener('DOMContentLoaded', function() {
    const generateBtn = document.getElementById('generate-btn');
    const loadingElement = document.getElementById('loading');
    const resultElement = document.getElementById('timetable-result');
    
    generateBtn.addEventListener('click', async function() {
        // Get form values
        const days = document.getElementById('days').value;
        const hours = document.getElementById('hours').value;
        const subjects = document.getElementById('subjects').value;
        const constraints = document.getElementById('constraints').value;

        
        // Validate inputs
        if (!subjects.trim()) {
            alert('Please enter at least one subject or activity');
            return;
        }
        
        // Show loading state
        loadingElement.style.display = 'flex';
        resultElement.innerHTML = '';
        
        try {
            // Prepare the prompt for DeepSeek
            const prompt = `Create a detailed schedule with the following requirements:
- Number of days: ${days}
- Hours per day: ${hours}
- Subjects/Activities: ${subjects}
- Special constraints: ${constraints || 'None'}

Format the timetable as an HTML table with appropriate styling. Include time slots for each day. Ensure the schedule is balanced and considers the constraints. Provide the result as HTML that can be directly rendered in a web page.`;
            
            // Call DeepSeek API (simulated here - replace with actual API call)
            const timetableHtml = await getDeepSeekResponse(prompt);
            
            // Display the result
            resultElement.innerHTML = timetableHtml;
        } catch (error) {
            console.error('Error generating timetable:', error);
            resultElement.innerHTML = `<div class="error">Error generating timetable. Please try again later.</div>`;
        } finally {
            loadingElement.style.display = 'none';
        }
    });
    
    // Function to simulate DeepSeek API call
    async function getDeepSeekResponse(prompt) {
        // In a real implementation, this would call the actual DeepSeek API
        // For demonstration, we'll simulate a response
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Extract parameters from prompt for our simulation
        const days = parseInt(prompt.match(/Number of days: (\d+)/)[1]);
        const hours = parseInt(prompt.match(/Hours per day: (\d+)/)[1]);
        const subjects = prompt.match(/Subjects\/Activities: ([^\n]+)/)[1].split(',').map(s => s.trim());
        const constraints = prompt.match(/Special constraints: ([^\n]+)/)[1];
        
        // Generate a simulated timetable
        return generateSimulatedTimetable(days, hours, subjects, constraints);
    }
    
    // Function to generate a simulated timetable (replace with actual API call)
    function generateSimulatedTimetable(days, hours, subjects, constraints) {
        const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].slice(0, days);
        const timeSlots = generateTimeSlots(8, hours); // Starting at 8am
        
        let html = `<table class="timetable">
            <thead>
                <tr>
                    <th>Time</th>`;
        
        // Add day headers
        dayNames.forEach(day => {
            html += `<th>${day}</th>`;
        });
        
        html += `</tr></thead><tbody>`;
        
        // Add time slots
        timeSlots.forEach((time, i) => {
            html += `<tr><td>${time}</td>`;
            
            // Add subjects for each day
            for (let j = 0; j < days; j++) {
                // Simple round-robin subject assignment
                const subjectIndex = (i + j) % subjects.length;
                const subject = subjects[subjectIndex];
                
                // Apply some constraints for simulation
                let finalSubject = subject;
                if (constraints.includes('No ' + subject + ' on ' + dayNames[j])) {
                    finalSubject = 'Free Period';
                }
                
                html += `<td>${finalSubject}</td>`;
            }
            
            html += `</tr>`;
        });
        
        html += `</tbody></table>`;
        
        // Add some notes
        html += `<div class="timetable-notes">
            <h3>Notes:</h3>
            <ul>
                <li>This timetable was generated based on your requirements</li>
                ${constraints !== 'None' ? `<li>Special constraints applied: ${constraints}</li>` : ''}
                <li>Total subjects: ${subjects.length}</li>
                <li>You can change time according to you</li>
            </ul>
        </div>`;
        
        return html;
    }
    
    // Helper function to generate time slot labels
    function generateTimeSlots(startHour, totalHours) {
        const slots = [];
        for (let i = 0; i < totalHours; i++) {
            const hour = startHour + i;
            const ampm = hour >= 12 ? 'PM' : 'AM';
            const displayHour = hour > 12 ? hour - 12 : hour;
            slots.push(`${displayHour}:00 ${ampm} - ${displayHour + 1}:00 ${ampm}`);
        }
        return slots;
    }
});