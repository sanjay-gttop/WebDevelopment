let timer, timer1;
let sec = 0, breakSec = 0;
let running = false, breakRunning = false;

// Updates the work timer display and checks if time is up
function updateTimer() {
    let hrs = Math.floor(sec / 3600);
    let mins = Math.floor((sec % 3600) / 60);
    let secs = sec % 60;

    let ehrs = document.getElementById("hrs1").value;
    let emin = document.getElementById("mins1").value;
    let targetTime = Number(ehrs) * 3600 + Number(emin) * 60;

    if (targetTime < sec) {
        playAlert1();
        resetbreak();
        alert("Time ended");
        stop();
        startbreak();
    } else {
        document.getElementById("timer").innerText = 
            `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
}

// Updates the break timer display and checks if break time is up
function updateTimerbreak() {
    let mins = Math.floor((breakSec % 3600) / 60);
    let secs = breakSec % 60;

    let bmins = document.getElementById("bmin").value;
    let breakTargetTime = Number(bmins) * 60;

    if (breakTargetTime < breakSec) {
        playAlert();
        alert("Break time ended");
        stop();
        reset();
        start();
    } else {
        document.getElementById("break").innerText = 
            `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
}

// Starts the work timer
function start() {
    if (!running) {
        running = true;
        timer = setInterval(() => {
            sec++;
            updateTimer();
        }, 1000);
    }
}

// Starts the break timer
function startbreak() {
    if (!breakRunning) {
        breakRunning = true;
        timer1 = setInterval(() => {
            breakSec++;
            updateTimerbreak();
        }, 1000);
    }
}

// Stops both timers
function stop() {
    clearInterval(timer);
    clearInterval(timer1);
    running = false;
    breakRunning = false;
}

// Resets both timers
function resetbutton() {
    reset();
    resetbreak();
}

// Resets the work timer
function reset() {
    clearInterval(timer);
    running = false;
    sec = 0;
    updateTimer();
}

// Resets the break timer
function resetbreak() {
    clearInterval(timer1);
    breakRunning = false;
    breakSec = 0;
    updateTimerbreak();
}

// Plays an alert sound when work time ends
function playAlert1() {
    document.getElementById("alertSound1").play();
}

// Plays an alert sound when break time ends
function playAlert() {
    document.getElementById("alertSound").play();
}
